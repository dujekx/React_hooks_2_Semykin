import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { tasksReducer } from './tasksReducer.js';
import { useTheme } from './ThemeContext.jsx';
import { useLanguage } from './LanguageContext.jsx';
import { ThemeToggle } from './components/ThemeToggle.jsx';
import { LanguageToggle } from './components/LanguageToggle.jsx';
import { AddTaskForm } from './components/AddTaskForm.jsx';
import { TaskList } from './components/TaskList.jsx';

export default function App() {
  const { theme } = useTheme();
  const { t } = useLanguage();
  const [tasks, dispatch] = useReducer(tasksReducer, []);
  const [filter, setFilter] = useState('all');
  const [query, setQuery] = useState('');
  const searchRef = useRef(null);

  const handleAdd = useCallback((text) => {
    dispatch({ type: 'add', task: { id: Date.now(), text, done: false } });
  }, []);
  const handleToggle = useCallback((id) => dispatch({ type: 'toggle', id }), []);
  const handleRemove = useCallback((id) => dispatch({ type: 'remove', id }), []);
  const handleRename = useCallback((id, text) => dispatch({ type: 'rename', id, text }), []);

  const visibleTasks = useMemo(() => {
    let list = tasks;
    if (filter === 'done') list = list.filter((x) => x.done);
    if (filter === 'active') list = list.filter((x) => !x.done);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((x) => x.text.toLowerCase().includes(q));
    return list;
  }, [tasks, filter, query]);

  const doneCount = useMemo(() => tasks.filter((x) => x.done).length, [tasks]);

  const percent = useMemo(
    () => (tasks.length ? Math.round((doneCount / tasks.length) * 100) : 0),
    [tasks.length, doneCount]
  );

  useEffect(() => {
    function onKeyDown(e) {
      const tag = document.activeElement.tagName;
      if (e.key === '/' && tag !== 'INPUT' && tag !== 'TEXTAREA') {
        e.preventDefault();
        searchRef.current.focus();
      }
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  return (
    <div className={'app ' + theme}>
      <div className="card">
        <header className="top">
          <h1>{t.title}</h1>
          <div className="top-actions">
            <LanguageToggle />
            <ThemeToggle />
          </div>
        </header>
        <AddTaskForm onAdd={handleAdd} />
        <input
          ref={searchRef}
          className="search"
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.search}
        />
        <div className="tabs">
          {[['all', t.all], ['active', t.active], ['done', t.done]].map(([key, label]) => (
            <button key={key} className={filter === key ? 'active' : ''} onClick={() => setFilter(key)}>
              {label}
            </button>
          ))}
        </div>
        <p className="muted">
          {t.total}: {tasks.length}, {t.completed}: {doneCount} ({percent}%)
        </p>
        <TaskList
          tasks={visibleTasks}
          onToggle={handleToggle}
          onRemove={handleRemove}
          onRename={handleRename}
        />
      </div>
    </div>
  );
}