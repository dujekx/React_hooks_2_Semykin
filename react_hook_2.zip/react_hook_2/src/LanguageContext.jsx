import { createContext, useContext, useMemo, useState } from 'react';

const dict = {
  ru: {
    title: 'Менеджер задач', newTask: 'Новая задача', add: 'Добавить',
    all: 'Все', active: 'Активные', done: 'Готовые',
    total: 'Всего', completed: 'выполнено', search: 'Поиск (нажми /)',
    dark: 'Тёмная', light: 'Светлая', edit: 'Редактирование',
    renamePrompt: 'Новый текст задачи:', langBtn: 'English',
  },
  en: {
    title: 'Task Manager', newTask: 'New task', add: 'Add',
    all: 'All', active: 'Active', done: 'Done',
    total: 'Total', completed: 'completed', search: 'Search (press /)',
    dark: 'Dark', light: 'Light', edit: 'Edit',
    renamePrompt: 'New task text:', langBtn: 'Русский',
  },
};

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState('ru');
  const value = useMemo(() => ({ lang, setLang, t: dict[lang] }), [lang]);
  return <LanguageContext value={value}>{children}</LanguageContext>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage нужно вызывать внутри LanguageProvider');
  return ctx;
}