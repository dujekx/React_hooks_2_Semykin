import { useLanguage } from '../LanguageContext.jsx';

export function LanguageToggle() {
  const { lang, setLang, t } = useLanguage();
  return <button onClick={() => setLang(lang === 'ru' ? 'en' : 'ru')}>{t.langBtn}</button>;
}