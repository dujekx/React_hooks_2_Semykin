import { useTheme } from '../ThemeContext.jsx';
import { useLanguage } from '../LanguageContext.jsx';

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const { t } = useLanguage();
  return (
    <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
      {theme === 'light' ? t.dark : t.light}
    </button>
  );
}